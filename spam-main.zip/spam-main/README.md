# Email Spam Classifier

This is a ML deployment project where I am deploying my Email Spam Classifier model into live production. I conducted a workshop to explain the steps of how I have deployed this model, please like, share and subscribe the video. 

Live Production UR: https://example-deployment-6cut.onrender.com

Workshop: https://www.youtube.com/watch?v=rgr_aCg-338
